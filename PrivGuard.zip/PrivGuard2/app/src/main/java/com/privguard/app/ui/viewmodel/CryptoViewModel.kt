package com.privguard.app.ui.viewmodel

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import com.privguard.app.crypto.EncryptionManager

class CryptoViewModel : ViewModel() {
    var inputText by mutableStateOf("")
        private set

    var outputText by mutableStateOf("")
        private set

    var isEncryptMode by mutableStateOf(true)
        private set

    var showError by mutableStateOf(false)
        private set

    fun onInputChange(newValue: String) {
        inputText = newValue
        showError = false
    }

    fun toggleMode() {
        isEncryptMode = !isEncryptMode
        inputText = ""
        outputText = ""
        showError = false
    }

    fun processText() {
        if (inputText.isBlank()) {
            showError = true
            return
        }

        outputText = if (isEncryptMode) {
            EncryptionManager.encrypt(inputText)
        } else {
            EncryptionManager.decrypt(inputText)
        }
    }

    fun copyToClipboard(context: Context) {
        if (outputText.isNotEmpty()) {
            val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            val clip = ClipData.newPlainText("PrivGuard Secret", outputText)
            clipboard.setPrimaryClip(clip)
        }
    }
}
