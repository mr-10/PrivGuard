package com.privguard.app.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable

private val DarkColorScheme = darkColorScheme(
    primary = CyberNeonBlue,
    onPrimary = CyberDarkBackground,
    secondary = CyberNeonPurple,
    onSecondary = CyberText,
    tertiary = CyberNeonPink,
    background = CyberDarkBackground,
    surface = CyberDarkSurface,
    onBackground = CyberText,
    onSurface = CyberText
)

private val LightColorScheme = lightColorScheme(
    primary = CyberElectricBlue,
    onPrimary = CyberLightSurface,
    secondary = CyberCyan,
    onSecondary = CyberLightSurface,
    background = CyberLightBackground,
    surface = CyberLightSurface,
    onBackground = CyberDarkText,
    onSurface = CyberDarkText
)

@Composable
fun PrivGuardTheme(
    darkTheme: Boolean,
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        content = content
    )
}
